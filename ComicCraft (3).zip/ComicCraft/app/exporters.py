from datetime import datetime
from pathlib import Path
from fpdf import FPDF
from .config import get_settings


def _pdf_text(value: str) -> str:
    return value.encode("latin-1", "replace").decode("latin-1")


def save_pdf(layout: list[dict], title: str = "ComicCraft Comic") -> str:
    settings = get_settings()
    filename = f"comic_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    output = settings.exports_dir / filename

    pdf = FPDF(orientation="P", unit="mm", format="A4")
    pdf.set_auto_page_break(auto=True, margin=15)
    for panel in layout:
        pdf.add_page()
        pdf.set_font("Helvetica", "B", 18)
        pdf.multi_cell(0, 10, _pdf_text(f"Panel {panel['panel_number']}: {panel['title']}"), new_x="LMARGIN", new_y="NEXT")
        image_rel = panel["image_path"].replace("/static/", "")
        image_path = settings.output_dir / image_rel
        if image_path.exists():
            pdf.image(str(image_path), x=15, y=35, w=180, h=120)
        pdf.set_y(160)
        pdf.set_font("Helvetica", "I", 10)
        pdf.multi_cell(0, 6, _pdf_text(panel["scene_description"]), new_x="LMARGIN", new_y="NEXT")
        pdf.ln(2)
        pdf.set_font("Helvetica", "B", 11)
        pdf.multi_cell(0, 6, _pdf_text("Caption: " + panel["caption"]), new_x="LMARGIN", new_y="NEXT")
        pdf.set_font("Helvetica", "", 11)
        pdf.multi_cell(0, 6, _pdf_text("Narration: " + panel["narration"]), new_x="LMARGIN", new_y="NEXT")
        if panel.get("dialogue"):
            pdf.set_font("Helvetica", "B", 11)
            pdf.multi_cell(0, 6, _pdf_text("Dialogue: " + panel["dialogue"]), new_x="LMARGIN", new_y="NEXT")
    pdf.output(str(output))
    return f"/static/exports/{filename}"
