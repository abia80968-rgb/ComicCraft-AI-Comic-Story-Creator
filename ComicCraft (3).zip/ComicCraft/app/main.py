from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from .config import get_settings
from .routes import router

settings = get_settings()

@asynccontextmanager
async def lifespan(app: FastAPI):
    settings.panels_dir.mkdir(parents=True, exist_ok=True)
    settings.exports_dir.mkdir(parents=True, exist_ok=True)
    settings.comics_dir.mkdir(parents=True, exist_ok=True)
    yield

app = FastAPI(title=settings.app_name, version="1.0.0", description="AI Comic Story Creator")
app.mount("/static", StaticFiles(directory=str(settings.output_dir)), name="static")
app.include_router(router)

@app.get("/health")
async def health():
    return {"status": "ok", "service": settings.app_name, "image_backend": settings.image_backend}
