from google import genai
from google.genai import types
from .config import get_settings
from .schemas import OutlineResponse, PromptRequest


def _client() -> genai.Client:
    settings = get_settings()
    if not settings.gemini_api_key:
        raise RuntimeError("GEMINI_API_KEY is not configured")
    return genai.Client(api_key=settings.gemini_api_key)


def generate_outline(request: PromptRequest) -> list[dict]:
    settings = get_settings()
    prompt = f"""
Create exactly {settings.max_panels} connected comic panels.
User story idea: {request.story_prompt}
Main character: {request.character_name}
Setting: {request.setting}
Tone: {request.tone}
Art style: {request.art_style}

Return a coherent beginning, development, turning point, and ending. Keep the same character identity,
clothing, environment, and visual continuity wherever appropriate. Each image_prompt must be a detailed
text-to-image prompt for a single comic panel and must NOT include speech bubbles or readable text.
"""
    response = _client().models.generate_content(
        model=settings.gemini_flash_model,
        contents=prompt,
        config=types.GenerateContentConfig(
            response_mime_type="application/json",
            response_schema=OutlineResponse,
            temperature=0.8,
        ),
    )
    parsed = response.parsed
    if isinstance(parsed, OutlineResponse):
        result = parsed
    else:
        result = OutlineResponse.model_validate_json(response.text)
    panels = result.panels[: settings.max_panels]
    if len(panels) != settings.max_panels:
        raise RuntimeError(f"Gemini returned {len(panels)} panels; expected {settings.max_panels}")
    return [panel.model_dump() for panel in panels]
