import re
from pathlib import Path
from uuid import uuid4
from PIL import Image, ImageDraw, ImageFont
from huggingface_hub import InferenceClient
from .config import get_settings


def _safe_name(value: str) -> str:
    return re.sub(r"[^a-zA-Z0-9_-]+", "_", value).strip("_")[:60] or "panel"


def _placeholder(prompt: str, path: Path) -> None:
    settings = get_settings()
    image = Image.new("RGB", (settings.image_width, settings.image_height), (245, 239, 226))
    draw = ImageDraw.Draw(image)
    draw.rectangle((12, 12, settings.image_width - 12, settings.image_height - 12), outline=(25, 25, 25), width=8)
    title = "ComicCraft Preview"
    text = prompt[:220]
    font = ImageFont.load_default()
    draw.text((32, 35), title, fill=(20, 20, 20), font=font)
    draw.multiline_text((32, 85), text, fill=(35, 35, 35), font=font, spacing=8)
    image.save(path, "PNG")


def _hf_generate(prompt: str, path: Path) -> None:
    settings = get_settings()
    if not settings.hf_api_key:
        raise RuntimeError("HF_API_KEY is not configured for IMAGE_BACKEND=hf")
    client = InferenceClient(api_key=settings.hf_api_key)
    image = client.text_to_image(
        prompt=prompt,
        model=settings.image_model,
        width=settings.image_width,
        height=settings.image_height,
        num_inference_steps=settings.image_steps,
    )
    image.save(path)


def _diffusers_generate(prompt: str, path: Path) -> None:
    settings = get_settings()
    try:
        import torch
        from diffusers import DiffusionPipeline
    except ImportError as exc:
        raise RuntimeError("Install requirements-diffusers.txt to use IMAGE_BACKEND=diffusers") from exc

    dtype = torch.float16 if torch.cuda.is_available() else torch.float32
    pipe = DiffusionPipeline.from_pretrained(settings.local_diffusers_model, torch_dtype=dtype)
    pipe = pipe.to("cuda" if torch.cuda.is_available() else "cpu")
    result = pipe(
        prompt,
        width=settings.image_width,
        height=settings.image_height,
        num_inference_steps=settings.image_steps,
    )
    result.images[0].save(path)


def generate_image(prompt: str, panel_number: int) -> str:
    settings = get_settings()
    filename = f"panel_{panel_number}_{uuid4().hex[:8]}_{_safe_name(prompt)}.png"
    path = settings.panels_dir / filename
    enriched = (
        f"{prompt}. Comic panel composition, strong readable silhouettes, expressive faces, clean line art, "
        "consistent character design, cinematic lighting, no words, no watermark, no logo."
    )
    if settings.image_backend == "hf":
        _hf_generate(enriched, path)
    elif settings.image_backend == "diffusers":
        _diffusers_generate(enriched, path)
    elif settings.image_backend == "placeholder":
        _placeholder(enriched, path)
    else:
        raise RuntimeError(f"Unsupported IMAGE_BACKEND: {settings.image_backend}")
    return f"/static/panels/{filename}"
