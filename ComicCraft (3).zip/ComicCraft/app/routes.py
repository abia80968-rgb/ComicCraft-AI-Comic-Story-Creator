from uuid import uuid4
from fastapi import APIRouter, Form, HTTPException, Request
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from .config import get_settings
from .schemas import PromptRequest
from .layout_builder import build_comic_layout
from .exporters import save_pdf
from .store import load_comic, save_comic

router = APIRouter()
templates = Jinja2Templates(directory=str(get_settings().output_dir.parent / "templates"))


def _request_data(story_prompt: str, character_name: str, setting: str, tone: str, art_style: str) -> PromptRequest:
    return PromptRequest(
        story_prompt=story_prompt,
        character_name=character_name,
        setting=setting,
        tone=tone,
        art_style=art_style,
    )


def generate_comic(request_data: PromptRequest) -> tuple[str, dict]:
    # Lazy imports keep the web server and health/docs routes available before AI SDKs are installed.
    from .gemini_flash import generate_outline
    from .gemini_pro import generate_story
    from .image_generator import generate_image
    outline = generate_outline(request_data)
    stories = generate_story(request_data, outline)
    images = [generate_image(panel["image_prompt"], panel["panel_number"]) for panel in outline]
    layout = build_comic_layout(outline, stories, images)
    comic_id = uuid4().hex
    payload = {
        "comic_id": comic_id,
        "request": request_data.model_dump(),
        "layout": layout,
    }
    save_comic(comic_id, payload)
    return comic_id, payload


@router.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse(request=request, name="index.html", context={})


@router.post("/generate", response_class=HTMLResponse)
async def generate_form(
    request: Request,
    story_prompt: str = Form(...),
    character_name: str = Form(...),
    setting: str = Form(...),
    tone: str = Form(...),
    art_style: str = Form(...),
):
    try:
        data = _request_data(story_prompt, character_name, setting, tone, art_style)
        comic_id, comic = generate_comic(data)
        return templates.TemplateResponse(request=request, name="comic_preview.html", context={**comic, "comic_id": comic_id})
    except Exception as exc:
        return templates.TemplateResponse(request=request, name="index.html", context={"error": str(exc), "form": locals()})


@router.post("/generate-comic/json")
async def generate_json(payload: PromptRequest):
    try:
        comic_id, comic = generate_comic(payload)
        return JSONResponse({"comic_id": comic_id, **comic, "pdf_url": f"/export/{comic_id}"})
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.get("/export/{comic_id}")
async def export_comic(comic_id: str):
    comic = load_comic(comic_id)
    if not comic:
        raise HTTPException(status_code=404, detail="Comic not found")
    try:
        pdf_url = save_pdf(comic["layout"], title="ComicCraft Comic")
        pdf_path = get_settings().output_dir.parent / pdf_url.lstrip("/")
        return FileResponse(str(pdf_path), media_type="application/pdf", filename=pdf_path.name)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.get("/export-success", response_class=HTMLResponse)
async def export_success(request: Request):
    return templates.TemplateResponse(request=request, name="export_success.html", context={})


@router.get("/test-image")
async def test_image(prompt: str = "A brave fox exploring an enchanted forest, comic book art"):
    try:
        from .image_generator import generate_image
        path = generate_image(prompt, 1)
        return {"image_url": path, "prompt": prompt}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
