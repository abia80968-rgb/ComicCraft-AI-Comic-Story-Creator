import json
from pathlib import Path
from .config import get_settings


def save_comic(comic_id: str, payload: dict) -> None:
    path = get_settings().comics_dir / f"{comic_id}.json"
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def load_comic(comic_id: str) -> dict | None:
    path = get_settings().comics_dir / f"{comic_id}.json"
    if not path.exists():
        return None
    return json.loads(path.read_text(encoding="utf-8"))
