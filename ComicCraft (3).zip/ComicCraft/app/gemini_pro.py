from google import genai
from google.genai import types
from .config import get_settings
from .schemas import StoryResponse, PromptRequest


def _client() -> genai.Client:
    settings = get_settings()
    if not settings.gemini_api_key:
        raise RuntimeError("GEMINI_API_KEY is not configured")
    return genai.Client(api_key=settings.gemini_api_key)


def generate_story(request: PromptRequest, outline: list[dict]) -> list[dict]:
    settings = get_settings()
    outline_text = "\n".join(
        f"Panel {p['panel_number']}: {p['title']} — {p['scene_description']}" for p in outline
    )
    prompt = f"""
Write the finished comic narration for these {settings.max_panels} panels.
Character: {request.character_name}
Setting: {request.setting}
Tone: {request.tone}
Art style: {request.art_style}
Original idea: {request.story_prompt}

Outline:
{outline_text}

For every panel provide a short ambient caption, a concise narration, and natural character dialogue.
Keep continuity across panels. Do not add extra panels. Dialogue may be empty when a panel has no speech.
"""
    response = _client().models.generate_content(
        model=settings.gemini_pro_model,
        contents=prompt,
        config=types.GenerateContentConfig(
            response_mime_type="application/json",
            response_schema=StoryResponse,
            temperature=0.9,
        ),
    )
    parsed = response.parsed
    result = parsed if isinstance(parsed, StoryResponse) else StoryResponse.model_validate_json(response.text)
    stories = result.panels[: settings.max_panels]
    if len(stories) != settings.max_panels:
        raise RuntimeError(f"Gemini returned {len(stories)} story panels; expected {settings.max_panels}")
    return [panel.model_dump() for panel in stories]
