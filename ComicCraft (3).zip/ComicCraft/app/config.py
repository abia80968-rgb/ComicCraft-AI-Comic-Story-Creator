from pathlib import Path
from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parent.parent

class Settings(BaseSettings):
    app_name: str = "ComicCraft"
    debug: bool = True
    gemini_api_key: str = ""
    gemini_flash_model: str = "gemini-2.5-flash"
    gemini_pro_model: str = "gemini-2.5-pro"
    hf_api_key: str = ""
    image_backend: str = "hf"  # hf | diffusers | placeholder
    image_model: str = "stabilityai/stable-diffusion-xl-base-1.0"
    local_diffusers_model: str = "stable-diffusion-v1-5/stable-diffusion-v1-5"
    image_width: int = 768
    image_height: int = 512
    image_steps: int = 20
    max_panels: int = 5
    output_dir: Path = BASE_DIR / "static"
    data_dir: Path = BASE_DIR / "data"

    model_config = SettingsConfigDict(env_file=BASE_DIR / ".env", env_file_encoding="utf-8", extra="ignore")

    @property
    def panels_dir(self) -> Path:
        return self.output_dir / "panels"

    @property
    def exports_dir(self) -> Path:
        return self.output_dir / "exports"

    @property
    def comics_dir(self) -> Path:
        return self.data_dir / "comics"

@lru_cache
def get_settings() -> Settings:
    settings = Settings()
    settings.panels_dir.mkdir(parents=True, exist_ok=True)
    settings.exports_dir.mkdir(parents=True, exist_ok=True)
    settings.comics_dir.mkdir(parents=True, exist_ok=True)
    return settings
