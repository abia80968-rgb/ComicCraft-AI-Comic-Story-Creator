def build_comic_layout(outline: list[dict], stories: list[dict], image_paths: list[str]) -> list[dict]:
    story_by_panel = {item["panel_number"]: item for item in stories}
    layout = []
    for index, panel in enumerate(outline):
        story = story_by_panel.get(panel["panel_number"], {})
        layout.append({
            "panel_number": panel["panel_number"],
            "title": panel["title"],
            "scene_description": panel["scene_description"],
            "image_prompt": panel["image_prompt"],
            "image_path": image_paths[index],
            "caption": story.get("caption", ""),
            "narration": story.get("narration", ""),
            "dialogue": story.get("dialogue", ""),
        })
    return layout
