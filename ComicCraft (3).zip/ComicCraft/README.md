# ComicCraft — AI Comic Story Creator

ComicCraft is a FastAPI web application based on the supplied project documentation. It accepts a story prompt, character, setting, tone, and art style; generates a five-panel outline, expands it into narration/dialogue, creates one illustration per panel, previews the comic, and exports it to PDF.

## Architecture

- **Frontend:** HTML + CSS + Jinja2
- **Backend:** FastAPI + Uvicorn
- **Story AI:** Google Gemini through the current `google-genai` SDK with Pydantic structured output
- **Image AI:** Hugging Face `InferenceClient` by default, with an optional local Hugging Face Diffusers backend
- **PDF:** `fpdf2`
- **Persistence:** generated comic metadata is stored as JSON in `data/comics`

The supplied document specified Gemini Flash for structured outlines, Gemini Pro for detailed narration/dialogue, Stable Diffusion for images, Jinja2 pages, FastAPI routes, and FPDF export; this implementation preserves that workflow while modernizing the SDK integration.

## Project tree

```text
ComicCraft/
├─ app/
│  ├─ __init__.py
│  ├─ config.py
│  ├─ exporters.py
│  ├─ gemini_flash.py
│  ├─ gemini_pro.py
│  ├─ image_generator.py
│  ├─ layout_builder.py
│  ├─ main.py
│  ├─ routes.py
│  ├─ schemas.py
│  └─ store.py
├─ data/comics/
├─ static/
│  ├─ css/styles.css
│  ├─ js/app.js
│  ├─ panels/
│  └─ exports/
├─ templates/
│  ├─ base.html
│  ├─ index.html
│  ├─ comic_preview.html
│  └─ export_success.html
├─ tests/
├─ .env.example
├─ .gitignore
├─ requirements.txt
├─ requirements-diffusers.txt
└─ README.md
```

## VS Code setup — Windows

1. Install **Python 3.11** (recommended for this project).
2. Open this `ComicCraft` folder in VS Code.
3. Open **Terminal → New Terminal**.
4. Create a virtual environment:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

5. Install the core dependencies:

```powershell
python -m pip install --upgrade pip
pip install -r requirements.txt
```

6. Copy `.env.example` to `.env` and add your API keys.

### Gemini key

Set `GEMINI_API_KEY` to a Gemini API key. The application uses the current Google GenAI Python SDK rather than the older `google-generativeai` package.

### Hugging Face image key

The default image backend is `hf`. Set `HF_API_KEY` to a Hugging Face access token. If your selected image model/provider requires additional permissions, grant them to the token.

## Run

```powershell
.\.venv\Scripts\Activate.ps1
uvicorn app.main:app --reload
```

Open:

- http://127.0.0.1:8000 — web application
- http://127.0.0.1:8000/docs — Swagger API documentation
- http://127.0.0.1:8000/health — health check

## Test the image service separately

After configuring `HF_API_KEY`:

```text
http://127.0.0.1:8000/test-image?prompt=A%20brave%20fox%20in%20an%20enchanted%20forest
```

## API example

POST JSON to `/generate-comic/json`:

```json
{
  "story_prompt": "A brave fox explores an enchanted forest and discovers a hidden portal.",
  "character_name": "Luna",
  "setting": "Enchanted forest",
  "tone": "Dramatic",
  "art_style": "Comic book"
}
```

The response contains `comic_id`, the complete panel layout, and a `pdf_url` for export.

## Local Diffusers mode

The project also supports the architecture described in the original document more literally by running Diffusers locally instead of hosted Hugging Face inference.

Install:

```powershell
pip install -r requirements-diffusers.txt
```

Then in `.env`:

```env
IMAGE_BACKEND=diffusers
LOCAL_DIFFUSERS_MODEL=stable-diffusion-v1-5/stable-diffusion-v1-5
```

A CUDA-capable GPU is strongly recommended for local diffusion generation. CPU generation can be very slow and memory-intensive.

## Fast UI-only smoke test without AI credentials

To verify FastAPI, Jinja2, static files and routing before adding API keys, temporarily use:

```env
IMAGE_BACKEND=placeholder
```

This does **not** replace Gemini: the `/generate` workflow still needs `GEMINI_API_KEY`. It only lets you test image rendering independently through `/test-image`.

## Automated tests

Run:

```powershell
pytest -q
```

The tests mock external AI services so they do not consume API quota.

## Troubleshooting

### `GEMINI_API_KEY is not configured`
Check that `.env` is in the project root and contains `GEMINI_API_KEY=...`. Restart Uvicorn after changing `.env`.

### Hugging Face authentication/model error
Check `HF_API_KEY`, the model ID in `IMAGE_MODEL`, and whether the selected provider/model is currently available to your account.

### PDF contains replacement characters
`fpdf2` uses a built-in Latin font in this implementation for portability. If you need full Unicode script support, configure a Unicode TTF font and register it in `app/exporters.py`.

### Local Diffusers is too slow
Use `IMAGE_BACKEND=hf` for hosted inference or use a GPU-enabled PyTorch installation for local Diffusers.
