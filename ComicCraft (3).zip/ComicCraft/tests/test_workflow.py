from app.schemas import PromptRequest
from app.layout_builder import build_comic_layout


def test_layout_builder():
    outline = [
        {"panel_number": 1, "title": "Arrival", "scene_description": "A forest gate", "image_prompt": "fox"},
        {"panel_number": 2, "title": "Discovery", "scene_description": "A glowing tree", "image_prompt": "tree"},
    ]
    stories = [
        {"panel_number": 1, "caption": "Night falls.", "narration": "Luna enters.", "dialogue": "Hello!"},
        {"panel_number": 2, "caption": "A light appears.", "narration": "She steps closer.", "dialogue": "What is that?"},
    ]
    result = build_comic_layout(outline, stories, ["/static/panels/a.png", "/static/panels/b.png"])
    assert len(result) == 2
    assert result[0]["dialogue"] == "Hello!"
